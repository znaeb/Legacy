(function() {
	// Magic!
	console.log("%cWelcome to your browser's developer tools!\nCheck back often for more fun!", 'background: #333; color: #ff9900');
})();